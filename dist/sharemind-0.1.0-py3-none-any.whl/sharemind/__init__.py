from .sharemind import SharemindSecret
