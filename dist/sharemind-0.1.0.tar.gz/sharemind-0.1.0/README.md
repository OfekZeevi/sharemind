# sharemind
A demonstation of the core functionality of the Sharemind secure multiparty computation system
